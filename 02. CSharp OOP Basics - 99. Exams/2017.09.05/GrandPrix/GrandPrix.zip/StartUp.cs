﻿using System;

namespace GrandPrix
{
    public class StartUp
    {
        public static void Main()
        {
            
        }
    }
}
