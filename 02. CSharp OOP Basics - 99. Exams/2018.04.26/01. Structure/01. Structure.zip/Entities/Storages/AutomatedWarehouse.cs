﻿using StorageMaster.Vehicles;
using System.Collections;
using System.Collections.Generic;

namespace StorageMaster.Storages
{
    public class AutomatedWarehouse : Storage
    {
        public const int defaultCapacity = 1;
        public const int defaultGarageSlots = 2;
        public static List<Vehicle> defaultVehicles = new List<Vehicle>()
        {
            new Truck()
        };

        public AutomatedWarehouse(string name)
            : base(name, defaultCapacity, defaultGarageSlots, defaultVehicles)
        {
        }
    }
}
