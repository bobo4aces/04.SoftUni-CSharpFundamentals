﻿using System;
using System.Collections.Generic;
using StorageMaster.Vehicles;

namespace StorageMaster.Storages
{
    public class Warehouse : Storage
    {
        public const int defaultCapacity = 10;
        public const int defaultGarageSlots = 10;
        public static List<Vehicle> defaultVehicles = new List<Vehicle>()
        {
            new Semi(),
            new Semi(),
            new Semi()
        };
        public Warehouse(string name) 
            : base(name, defaultCapacity, defaultGarageSlots, defaultVehicles)
        {
        }
    }
}
