﻿using System;
using System.Collections.Generic;
using StorageMaster.Vehicles;

namespace StorageMaster.Storages
{
    public class DistributionCenter : Storage
    {
        public const int defaultCapacity = 2;
        public const int defaultGarageSlots = 5;
        public static List<Vehicle> defaultVehicles = new List<Vehicle>()
        {
            new Van(),
            new Van(),
            new Van()
        };
        public DistributionCenter(string name)
            : base(name, defaultCapacity, defaultGarageSlots, defaultVehicles)
        {
        }
    }
}
