﻿using StorageMaster.Vehicles;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StorageMaster.Storages
{
    public abstract class Storage
    {
        private IReadOnlyCollection<Vehicle> garage;

        public string Name { get; set; }
        public int Capacity { get; set; }
        public int GarageSlots { get; set; }
        
        public IReadOnlyCollection<Product> Products { get; set; }

        public Storage(string name, int capacity, int garageSlots, IEnumerable<Vehicle> vehicles)
        {
            Name = name;
            Capacity = capacity;
            GarageSlots = garageSlots;
            Garage = vehicles.ToArray();
            Products = new List<Product>();
        }
        public IReadOnlyCollection<Vehicle> Garage
        {
            get
            {
                return garage;
            }
            set
            {
                Vehicle[] currentGarage = new Vehicle[GarageSlots];
                int index = 0;
                foreach (var item in value)
                {
                    currentGarage[index] = item;
                    index++;
                }
                garage = currentGarage;
            }

        }
        public bool IsFull()
        {
            return Products.Sum(p=>p.Weight) >= Capacity;
        }

        public Vehicle GetVehicle(int garageSlot)
        {
            if (garageSlot >= GarageSlots)
            {
                throw new InvalidOperationException("Invalid garage slot!");
            }
            Vehicle vehicle = Garage.ElementAt(garageSlot);
            if (vehicle == null)
            {
                throw new InvalidOperationException("No vehicle in this garage slot!");
            }
            return vehicle;
        }

        public int SendVehicleTo(int garageSlot, Storage deliveryLocation)
        {
            Vehicle vehicle = GetVehicle(garageSlot);
            Vehicle[] garageFrom = Garage.ToArray();
            Vehicle[] garageTo = deliveryLocation.Garage.ToArray();
            if (garageTo.All(s=>s == null))
            {
                throw new InvalidOperationException("No room in garage!");
            }
            garageFrom[garageSlot] = null;
            for (int i = 0; i < garageTo.Length; i++)
            {
                if (garageTo[i] == null)
                {
                    garageTo[i] = vehicle;
                    return i;
                }
            }
            return 0;
        }

        public int UnloadVehicle(int garageSlot)
        {
            if (IsFull())
            {
                throw new InvalidOperationException("Storage is full!");
            }
            Vehicle vehicle = GetVehicle(garageSlot);
            int unloadedProductsCount = 0;
            List<Product> currentProducts = Products.ToList();
            while (true)
            {
                if (vehicle == null)
                {
                    break;
                }
                if (vehicle.IsEmpty())
                {
                    break;
                }
                if (IsFull())
                {
                    break;
                }
                currentProducts.Add(vehicle.Unload());
                unloadedProductsCount++;
            }
            Products = currentProducts;
            return unloadedProductsCount;
        }
    }
}
