﻿//using StorageMaster.Vehicles;
//using System;
//using System.Collections.Generic;
//using System.Text;

//namespace StorageMaster
//{
//    public class VehicleFactory
//    {
//        public Vehicle CreateVehicle(string[] vehicleInfo)
//        {

//        }
//    }
//}
