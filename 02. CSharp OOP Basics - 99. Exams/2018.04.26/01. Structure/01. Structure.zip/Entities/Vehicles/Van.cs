﻿namespace StorageMaster.Vehicles
{
    public class Van : Vehicle
    {
        public Van() : base(2)
        {
        }
    }
}
