﻿namespace StorageMaster
{
    public class Gpu : Product
    {
        public Gpu(double price, double weight = 0.7) : base(price, weight)
        {
        }
    }
}
