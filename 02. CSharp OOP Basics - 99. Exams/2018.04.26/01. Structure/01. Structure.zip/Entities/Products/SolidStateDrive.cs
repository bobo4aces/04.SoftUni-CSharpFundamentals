﻿namespace StorageMaster
{
    public class SolidStateDrive : Product
    {
        public SolidStateDrive(double price, double weight = 0.2) : base(price, weight)
        {
        }
    }
}
