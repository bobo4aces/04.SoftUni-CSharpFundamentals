﻿namespace StorageMaster
{
    public class Ram : Product
    {
        public Ram(double price, double weight = 0.1) : base(price, weight)
        {
        }
    }
}
