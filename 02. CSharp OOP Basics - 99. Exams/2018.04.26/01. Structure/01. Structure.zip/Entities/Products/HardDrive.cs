﻿namespace StorageMaster
{
    public class HardDrive : Product
    {
        public HardDrive(double price, double weight = 1) : base(price, weight)
        {
        }
    }
}
