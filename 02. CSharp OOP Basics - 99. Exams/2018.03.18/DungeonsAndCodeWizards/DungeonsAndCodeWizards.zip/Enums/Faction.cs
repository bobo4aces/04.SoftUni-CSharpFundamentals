﻿namespace DungeonsAndCodeWizards.Enums
{
    public enum Faction
    {
        CSharp,
        Java
    }
}
