﻿namespace DungeonsAndCodeWizards.Entities.Bags
{
    public class Satchel : Bag
    {
        public Satchel() : base(20)
        {
        }
    }
}
