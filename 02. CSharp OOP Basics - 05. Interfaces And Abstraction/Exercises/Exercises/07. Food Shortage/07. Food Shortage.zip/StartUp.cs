﻿using FoodShortage.Core;
using System;

namespace FoodShortage
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
