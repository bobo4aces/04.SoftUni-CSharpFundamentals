﻿using BorderControl.Core;
using System;

namespace BorderControl
{
    public class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
