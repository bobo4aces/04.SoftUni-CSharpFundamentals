﻿namespace MilitaryElite.Interfaces
{
    public interface ISpecialisedSoldier
    {
        string Corp { get; }
    }
}