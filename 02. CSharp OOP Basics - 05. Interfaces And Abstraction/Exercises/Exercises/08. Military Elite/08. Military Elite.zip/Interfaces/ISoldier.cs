﻿namespace MilitaryElite.Interfaces
{
    public interface ISoldier
    {
        string Id { get; }
        string Firstname { get; }
        string Lastname { get; }
    }
}