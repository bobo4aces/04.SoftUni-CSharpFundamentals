﻿namespace Telephony
{
    public interface IBrowseable
    {
        string Browsing(string site);
    }
}
