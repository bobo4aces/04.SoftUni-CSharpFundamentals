﻿namespace RawData
{
    public class Tire
    {
        public double Presure
        {
            get;
            set;
        }
        public int Age
        {
            get;
            set;
        }

        public Tire(double presure, int age)
        {
            Presure = presure;
            Age = age;
        }
    }
}
