﻿namespace DatabaseExtended
{
    public class Program
    {
        public static void Main()
        {
        }
    }
}
