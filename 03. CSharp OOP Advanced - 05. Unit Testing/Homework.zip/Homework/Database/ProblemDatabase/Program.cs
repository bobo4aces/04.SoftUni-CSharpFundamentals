﻿namespace ProblemDatabase
{
    class Program
    {
        static void Main()
        {
        }
    }
}
