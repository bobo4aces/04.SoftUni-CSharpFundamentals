﻿namespace WildFarm.Contracts
{
    public interface ICat : IFeline
    {
        string Breed { get; }
    }
}
