﻿namespace WildFarm.Contracts
{
    public interface IFeline : IMammal
    {
        //TODO Check this
        string Breed { get; }
    }
}
