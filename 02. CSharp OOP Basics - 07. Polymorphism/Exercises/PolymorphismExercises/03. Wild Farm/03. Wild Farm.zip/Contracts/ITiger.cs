﻿namespace WildFarm.Contracts
{
    public interface ITiger : IFeline
    {
        string Breed { get; }
    }
}
