﻿using System;
using WildFarm.Core;

namespace WildFarm
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
