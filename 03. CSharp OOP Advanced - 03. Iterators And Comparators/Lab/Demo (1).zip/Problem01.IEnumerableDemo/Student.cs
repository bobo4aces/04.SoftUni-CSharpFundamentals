﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem01.IEnumerableDemo
{
    public class Student 
    {
        public string Name { get; set; }
    }
}
