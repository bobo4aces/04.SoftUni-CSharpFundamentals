﻿using _06._Generic_Count_Method_Double.Core;

namespace _06._Generic_Count_Method_Double
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
