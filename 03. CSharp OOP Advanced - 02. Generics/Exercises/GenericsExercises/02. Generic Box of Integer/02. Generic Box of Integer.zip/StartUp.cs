﻿using _02._Generic_Box_of_Integer.Core;

namespace _02._Generic_Box_of_Integer
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
