﻿using _04._Generic_Swap_Method_Integer.Core;

namespace _04._Generic_Swap_Method_Integer
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
