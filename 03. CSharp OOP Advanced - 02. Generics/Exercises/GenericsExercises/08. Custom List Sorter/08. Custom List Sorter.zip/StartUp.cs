﻿using _08._Custom_List_Sorter.Core;

namespace _08._Custom_List_Sorter
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
