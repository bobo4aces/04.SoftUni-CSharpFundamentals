﻿using _03._Generic_Swap_Method_String.Core;

namespace _03._Generic_Swap_Method_String
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
