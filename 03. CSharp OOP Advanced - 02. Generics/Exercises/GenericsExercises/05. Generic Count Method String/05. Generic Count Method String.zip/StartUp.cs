﻿using _05._Generic_Count_Method_String.Core;

namespace _05._Generic_Count_Method_String
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
