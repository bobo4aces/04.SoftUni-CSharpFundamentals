﻿using _01._Generic_Box_of_String.Core;

namespace _01._Generic_Box_of_String
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
