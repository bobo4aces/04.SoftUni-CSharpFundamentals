﻿using _07._Custom_List.Core;

namespace _07._Custom_List
{
    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
