﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06._Traffic_Lights
{
    public enum TrafficLightColor
    {
        Red, 
        Green,
        Yellow
    }
}
