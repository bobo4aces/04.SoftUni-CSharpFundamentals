﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07._Inferno_Infinity.Contracts
{
    public interface IWriter
    {
        void WriteLine(string line);
    }
}
