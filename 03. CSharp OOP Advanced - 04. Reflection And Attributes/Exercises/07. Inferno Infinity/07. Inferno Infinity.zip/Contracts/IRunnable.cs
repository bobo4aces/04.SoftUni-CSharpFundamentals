﻿namespace _07._Inferno_Infinity.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
