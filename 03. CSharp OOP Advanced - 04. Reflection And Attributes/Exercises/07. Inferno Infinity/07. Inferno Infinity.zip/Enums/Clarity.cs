﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07._Inferno_Infinity.Enums
{
    public enum Clarity
    {
        Chipped = 1,
        Regular = 2,
        Perfect = 5,
        Flawless = 10
    }
}
