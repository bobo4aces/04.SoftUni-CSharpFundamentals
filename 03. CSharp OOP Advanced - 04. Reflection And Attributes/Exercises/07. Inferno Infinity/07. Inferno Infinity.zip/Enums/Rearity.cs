﻿namespace _07._Inferno_Infinity.Enums
{
    public enum Rearity
    {
        Common = 1,
        Uncommon = 2,
        Rare = 3,
        Epic = 5
    }
}
