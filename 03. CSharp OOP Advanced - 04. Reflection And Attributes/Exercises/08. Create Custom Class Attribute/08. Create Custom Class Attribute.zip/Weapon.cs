﻿using System;
using System.Linq;

namespace _08._Create_Custom_Class_Attribute
{
    [Default("Pesho", 3, "Used for C# OOP Advanced Course - Enumerations and Attributes.", "Pesho", "Svetlio")]
    public abstract class Weapon
    {
    }
}
