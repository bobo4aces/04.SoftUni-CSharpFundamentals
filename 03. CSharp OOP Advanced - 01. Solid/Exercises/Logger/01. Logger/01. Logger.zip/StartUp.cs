﻿namespace MyLogger
{
    using MyLogger.Core;

    class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
