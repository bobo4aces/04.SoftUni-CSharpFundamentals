﻿using AnimalCentre.Models.Animals;
using AnimalCentre.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalCentre.Models.Procedures
{
    public class Procedure : IProcedure
    {
        private ICollection<IAnimal> ProcedureHistory { get; set; }

        public Procedure()
        {
            ProcedureHistory = new List<IAnimal>();
        }

        public string History()
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var animal in ProcedureHistory)
            {
                stringBuilder.AppendLine($"{GetType().Name}");
                stringBuilder.AppendLine($"    - {animal.Name} - Happiness: {animal.Happiness} - Energy: {animal.Energy}");
            }
            return stringBuilder.ToString().TrimEnd();
        }

        public virtual void DoService(IAnimal animal, int procedureTime)
        {
            if (animal.ProcedureTime < procedureTime)
            {
                throw new ArgumentException("Animal doesn't have enough procedure time");
            }
            animal.ProcedureTime -= procedureTime;
            ProcedureHistory.Add(animal);
        }

    }
}
