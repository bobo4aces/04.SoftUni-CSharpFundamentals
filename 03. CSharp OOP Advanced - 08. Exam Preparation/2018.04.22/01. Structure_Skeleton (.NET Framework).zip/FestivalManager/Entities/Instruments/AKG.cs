﻿namespace FestivalManager.Entities.Instruments
{
    public class AKG : Microphone
    {
    }
}
