﻿namespace FestivalManager.Entities.Instruments
{
    public class Shure : Microphone
    {
    }
}
