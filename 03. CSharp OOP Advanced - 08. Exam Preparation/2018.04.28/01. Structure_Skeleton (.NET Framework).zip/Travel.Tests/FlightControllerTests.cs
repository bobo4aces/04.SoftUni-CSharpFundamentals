﻿// REMOVE any "using" statements, which start with "Travel." BEFORE SUBMITTING

namespace Travel.Tests
{
	using NUnit.Framework;

	[TestFixture]
    public class FlightControllerTests
    {
	    [Test]
	    public void Test1()
	    {
	    }
    }
}
