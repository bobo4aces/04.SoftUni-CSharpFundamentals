﻿namespace Travel.Entities.Items
{
	public class Computer : Item
	{
		public Computer()
			: base(3000)
		{
		}
	}
}