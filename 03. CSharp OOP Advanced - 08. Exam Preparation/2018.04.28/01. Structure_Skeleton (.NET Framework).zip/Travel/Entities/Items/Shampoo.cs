﻿namespace Travel.Entities.Items
{
	public class Shampoo : Item
	{
		public Shampoo()
			: base(4)
		{
		}
	}
}