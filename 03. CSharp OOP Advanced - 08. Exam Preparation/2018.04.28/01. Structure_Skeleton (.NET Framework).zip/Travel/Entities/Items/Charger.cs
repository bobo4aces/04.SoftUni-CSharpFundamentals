﻿namespace Travel.Entities.Items
{
	public class Charger : Item
	{
		public Charger()
			: base(5)
		{
		}
	}
}