﻿namespace Travel.Entities.Items
{
	public class Headphones : Item
	{
		public Headphones()
			: base(100)
		{
		}
	}
}