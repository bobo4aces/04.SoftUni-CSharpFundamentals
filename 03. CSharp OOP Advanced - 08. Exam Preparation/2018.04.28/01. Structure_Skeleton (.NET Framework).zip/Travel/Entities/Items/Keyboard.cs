﻿namespace Travel.Entities.Items
{
	public class Keyboard : Item
	{
		public Keyboard()
			: base(20)
		{
		}
	}
}