﻿namespace Travel.Entities.Items
{
	public class FlashDrive : Item
	{
		public FlashDrive()
			: base(20)
		{
		}
	}
}