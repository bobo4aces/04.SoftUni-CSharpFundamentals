﻿namespace Travel.Entities.Items
{
	public class Toothpicks : Item
	{
		public Toothpicks()
			: base(int.MinValue)
		{
		}
	}
}