﻿namespace Travel.Entities.Airplanes
{
	public class LightVimaan : Vimaan
	{
		public LightVimaan()
			: base(mesta: 5, chanti: 8)
		{
		}
	}
}