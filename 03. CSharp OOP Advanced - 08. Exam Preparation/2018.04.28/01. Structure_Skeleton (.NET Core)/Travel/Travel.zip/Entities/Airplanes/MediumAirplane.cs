﻿namespace Travel.Entities.Airplanes
{
	public class MediumAirplane : Airplane
    {
		public MediumAirplane()
			: base(10, 14)
		{
		}
	}
}