﻿namespace Travel.Entities.Items
{
	public class CellPhone : Item
	{
		public CellPhone()
			: base(700)
		{
		}
	}
}